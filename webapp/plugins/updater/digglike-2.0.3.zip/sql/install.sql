
/*!40000 ALTER TABLE `core_admin_right` DISABLE KEYS */;
INSERT INTO `core_admin_right` (`id_right`,`name`,`level_right`,`admin_url`,`description`,`is_updatable`,`plugin_name`,`id_feature_group`,`icon_url`,`documentation_url`) VALUES 
('DIGGLIKE_MANAGEMENT','digglike.adminFeature.digglike_management.name',2,'jsp/admin/plugins/digglike/ManagePluginDigglike.jsp','digglike.adminFeature.digglike_management.description',0,'digglike','APPLICATIONS','images/admin/skin/plugins/digglike/digglike.png', NULL);
/*!40000 ALTER TABLE `core_admin_right` ENABLE KEYS */;


--
-- Table structure for table `digglike_default_message`
--
DROP TABLE IF EXISTS `digglike_default_message`;
CREATE TABLE `digglike_default_message` (
  `unavailability_message` text,
  `libelle_validate_button`varchar(255),
  `libelle_contribution` varchar(255),
  `number_digg_submit_in_top_score`int(11),
  `number_digg_submit_in_top_comment`int(11),
  `number_digg_submit_caracters_shown`int(11)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_digg`
--

DROP TABLE IF EXISTS `digglike_digg`;
CREATE TABLE `digglike_digg` (
  `id_digg` int(11) NOT NULL default 0,
  `title` text ,
  `unavailability_message` text,
  `workgroup` varchar(255),
  `id_vote_type` int(11) NOT NULL default 0,
  `number_vote_required` int(11),
  `number_day_required` int(11),
  `active_digg_submit_authentification` tinyint(1) default 0,
  `active_vote_authentification` tinyint(1) default 0,
  `active_comment_authentification` tinyint(1) default 0,
  `disable_new_digg_submit` tinyint(1) default 0,
  `authorized_comment` tinyint(1) default 0,
  `disable_new_comment` tinyint(1) default 0,
  `id_mailing_list_digg_submit` int(11) default NULL,
  `id_mailing_list_comment` int(11) default NULL,
  `active_captcha` tinyint(1) default 0,
  `active` tinyint(1) default 0,
  `date_creation` timestamp NULL default NULL,
  `libelle_validate_button` varchar(255),
  `active_digg_proposition_state` tinyint(1) default 0,
  `libelle_contribution` varchar(255) NOT NULL,
  `number_digg_submit_in_top_score`int(11),
  `number_digg_submit_in_top_comment`int(11),
  `limit_number_vote` tinyint(1) default NULL,
  `number_digg_submit_caracters_shown`int(11),
  `show_category_block` tinyint(1) default 0,
  `show_top_score_block` tinyint(1) default 0,
  `show_top_comment_block` tinyint(1) default 0,
   
  PRIMARY KEY  (`id_digg`),
  KEY `vote_type_fk` (`id_vote_type`),
  CONSTRAINT `fk_vote_type` FOREIGN KEY (`id_vote_type`) REFERENCES `digglike_vote_type` (`id_vote_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_vote_type`
--

DROP TABLE IF EXISTS `digglike_vote_type`;
CREATE TABLE `digglike_vote_type` (
  `id_vote_type` int(11) NOT NULL default '0',
  `title` varchar(255),
  PRIMARY KEY  (`id_vote_type`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_entry`
--

DROP TABLE IF EXISTS `digglike_entry`;
CREATE TABLE `digglike_entry` (
  `id_entry` int(11) NOT NULL default 0,
  `id_digg` int(11) NOT NULL default 0,
  `id_type` int(11) NOT NULL default 0,
  `title` text,
  `help_message` text,
  `entry_comment` text,
  `mandatory` tinyint(1) default 0,
  `position` int(11) default NULL,
  `default_value` text,
  `height` int(11) default NULL,
  `width` int(11) default NULL,
  `max_size_enter` int(11) default NULL,
  `show_in_digg_submit_list` tinyint(1) default 0,
  PRIMARY KEY  (`id_entry`),
  KEY `digg_fk` (`id_digg`),
  KEY `entry_type_fk` (`id_type`),
  CONSTRAINT `fk_entry_type` FOREIGN KEY (`id_type`) REFERENCES `digglike_entry_type` (`id_type`),
  CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_entry_type`
--

DROP TABLE IF EXISTS `digglike_entry_type`;
CREATE TABLE `digglike_entry_type` (
  `id_type` int(11) NOT NULL default 0,
  `title` varchar(255),
  `class_name` varchar(255),
  PRIMARY KEY  (`id_type`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




--
-- Table structure for table `digglike_category`
--

DROP TABLE IF EXISTS `digglike_category`;
CREATE TABLE `digglike_category` (
	`id_category` int(11) NOT NULL,
	`title` varchar(100) NOT NULL,
	PRIMARY KEY  (`id_category`)	
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_digg_category`
--

DROP TABLE IF EXISTS `digglike_digg_category`;
CREATE TABLE `digglike_digg_category` (
  `id_digg` int(11) NOT NULL default 0,
  `id_category` int(11) NOT NULL default 0,
  PRIMARY KEY  (`id_digg`,`id_category`),
  KEY `contain3_fk` (`id_digg`),
  KEY `contain3_fk2` (`id_category`),
  CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`),
  CONSTRAINT `fk_category` FOREIGN KEY (`id_category`) REFERENCES `digglike_category` (`id_category`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




--
-- Table structure for table `digglike_regular_expression`
--

DROP TABLE IF EXISTS `digglike_regular_expression`;
CREATE TABLE `digglike_regular_expression` (
  `id_expression` int(11) NOT NULL default 0,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `valid_exemple` varchar(255) NOT NULL,
  `information_message` text NOT NULL,
  `error_message` text,
  PRIMARY KEY  (`id_expression`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_response`
--

DROP TABLE IF EXISTS `digglike_response`;
CREATE TABLE `digglike_response` (
  `id_response` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `response_value`  text,
  `id_entry` int(11) default NULL,
   PRIMARY KEY  (`id_response`),
   KEY `entry_fk` (`id_entry`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_digg_submit`
--

DROP TABLE IF EXISTS `digglike_digg_submit`;
CREATE TABLE `digglike_digg_submit` (
   `id_digg_submit` int(11) NOT NULL default 0,
   `id_digg` int(11) NOT NULL default 0,
   `id_state` int(11) NOT NULL default 0,
   `user_login` varchar(100) collate utf8_unicode_ci default NULL,
   `date_response` timestamp NULL default NULL,
   `vote_number`  int(11) default NULL,
   `score_number` int(11) default NULL,
   `id_category` int(11) default NULL ,
   `digg_submit_value`  text,
   `digg_submit_title`  text,
   `comment_enable_number`  int(11) default NULL,
   `digg_submit_value_show_in_the_list`  text,
   `reported` tinyint(1) default 0,
   `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL,
   PRIMARY KEY  (`id_digg_submit`),
   KEY `digg_fk` (`id_digg`),
   KEY `category_fk` (`id_category`),
   CONSTRAINT `fk_category` FOREIGN KEY (`id_category`) REFERENCES `digglike_category` (`id_category`),
   CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
--
-- Table structure for table `digglike_digg_submit_state`
--

DROP TABLE IF EXISTS `digglike_digg_submit_state`;
CREATE TABLE `digglike_digg_submit_state` (
  `id_state` int(3) NOT NULL default 0,
  `title` varchar(255),
  `number` int(3) NOT NULL default 0,
	 PRIMARY KEY  (`id_state`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote`
--

DROP TABLE IF EXISTS `digglike_comment_submit`;
CREATE TABLE `digglike_comment_submit` (
  `id_comment_submit` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `date_comment` timestamp NULL default NULL,
  `comment_value`  text,
  `active` tinyint(1) default 0,
  `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL,
  
   PRIMARY KEY  (`id_comment_submit`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_response`
--

DROP TABLE IF EXISTS `digglike_response`;
CREATE TABLE `digglike_response` (
  `id_response` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `response_value`  text,
  `id_entry` int(11) default NULL,
   PRIMARY KEY  (`id_response`),
   KEY `entry_fk` (`id_entry`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   
   CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_verify_by`
--

DROP TABLE IF EXISTS `digglike_entry_verify_by`;
CREATE TABLE `digglike_entry_verify_by` (
  `id_entry` int(11) NOT NULL default 0,
  `id_expression` int(11) NOT NULL default 0,
  PRIMARY KEY  (`id_entry`,`id_expression`),
  KEY `contain3_fk` (`id_entry`),
  KEY `contain3_fk2` (`id_expression`),
  CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
  CONSTRAINT `fk_expression_reguliere` FOREIGN KEY (`id_expression`) REFERENCES `digglike_regular_expression` (`id_expression`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_action`
--

DROP TABLE IF EXISTS `digglike_action`;
CREATE TABLE `digglike_action` (
  `id_action` int(11) NOT NULL default 0,
  `name_key` varchar(100) collate utf8_unicode_ci default NULL,
  `description_key` varchar(100) collate utf8_unicode_ci default NULL,
  `action_url` varchar(255) collate utf8_unicode_ci default NULL,
  `icon_url` varchar(255) collate utf8_unicode_ci default NULL,
  `action_permission` varchar(255) collate utf8_unicode_ci default NULL,
  `digg_state` tinyint(1) default 0,
  PRIMARY KEY  (`id_action`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_tag_submit`
--

DROP TABLE IF EXISTS `digglike_tag_submit`;
CREATE TABLE `digglike_tag_submit` (
   `id_tag_submit` int(11) NOT NULL default 0,
   `id_digg_submit` int(11) NOT NULL default 0,
   `tag_value`  text,
    PRIMARY KEY  (`id_tag_submit`),
    KEY `diggsubmit_fk` (`id_digg_submit`),
	CONSTRAINT `fk_diggsubmit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg_submit` (`id_digg_submit`)

)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote_type_vote_button`
--

DROP TABLE IF EXISTS `digglike_vote_type_vote_button`;
CREATE TABLE `digglike_vote_type_vote_button` (
  `id_vote_type` int(11) NOT NULL default 0,
  `id_vote_button` int(11) NOT NULL default 0,
  `vote_button_order` int(11) default NULL ,
  
  PRIMARY KEY  (`id_vote_type`,`id_vote_button`),
  KEY `contain3_fk` (`id_vote_type`),
  KEY `contain3_fk2` (`id_vote_button`),
  CONSTRAINT `fk_votetype` FOREIGN KEY (`id_vote_type`) REFERENCES `digglike_vote_type` (`id_vote_type`),
  CONSTRAINT `fk_votebutton` FOREIGN KEY (`id_vote_button`) REFERENCES `digglike_vote_button` (`id_vote_button`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote_button`
--

DROP TABLE IF EXISTS `digglike_vote_button`;
CREATE TABLE `digglike_vote_button` (
	`id_vote_button` int(11) NOT NULL,
	`title` varchar(100) NOT NULL,
	`vote_button_value` int(11) default NULL,
	`icon_content` longblob DEFAULT NULL,
	`icon_mime_type` varchar(100) DEFAULT NULL,
	PRIMARY KEY  (`id_vote_button`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote`
--

DROP TABLE IF EXISTS `digglike_vote`;
CREATE TABLE `digglike_vote` (
    `id_digg_submit` int(11) NOT NULL default 0,
      `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL
 )  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_export_format`
--

DROP TABLE IF EXISTS `digglike_export_format`;
CREATE TABLE `digglike_export_format` (
  `id_export` int(11) NOT NULL default '0',
  `title` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `extension` varchar(255) default NULL,
  `xsl_file` blob,
  PRIMARY KEY  (`id_export`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Init  table `digglike_entry_type`
--

insert into digglike_entry_type(id_type,title,class_name) values(1,"Url","fr.paris.lutece.plugins.digglike.business.EntryTypeUrl");
insert into digglike_entry_type(id_type,title,class_name) values(2,"Zone de texte court","fr.paris.lutece.plugins.digglike.business.EntryTypeText");
insert into digglike_entry_type(id_type,title,class_name) values(3,"Zone de texte long","fr.paris.lutece.plugins.digglike.business.EntryTypeTextArea");
 
--
-- Init  table `digglike_action`
--
insert into digglike_action( id_action,name_key,description_key,action_url,icon_url,action_permission,digg_state) 
values
	  (1,"digglike.action.modify.name","digglike.action.modify.description","jsp/admin/plugins/digglike/ModifyDigg.jsp","images/admin/skin/plugins/digglike/actions/modify.png","MODIFY",0),
	  (2,"digglike.action.modify.name","digglike.action.modify.description","jsp/admin/plugins/digglike/ModifyDigg.jsp","images/admin/skin/plugins/digglike/actions/modify.png","MODIFY",1),
	  (3,"digglike.action.manageDiggSubmit.name","digglike.action.manageDiggSubmit.description","jsp/admin/plugins/digglike/ManageDiggSubmit.jsp","images/admin/skin/plugins/digglike/actions/proposition.png","MANAGE_DIGG_SUBMIT",0),
	  (4,"digglike.action.manageDiggSubmit.name","digglike.action.manageDiggSubmit.description","jsp/admin/plugins/digglike/ManageDiggSubmit.jsp","images/admin/skin/plugins/digglike/actions/proposition.png","MANAGE_DIGG_SUBMIT",1),
	  (5,"digglike.action.disable.name","digglike.action.disable.description","jsp/admin/plugins/digglike/ConfirmDisableDigg.jsp","images/admin/skin/plugins/digglike/actions/disable.png","CHANGE_STATE",1),
	  (6,"digglike.action.enable.name","digglike.action.enable.description","jsp/admin/plugins/digglike/DoEnableDigg.jsp","images/admin/skin/plugins/digglike/actions/enable.png","CHANGE_STATE",0),
	  (7,"digglike.action.copy.name","digglike.action.copy.description","jsp/admin/plugins/digglike/DoCopyDigg.jsp","images/admin/skin/plugins/digglike/actions/editcopy.png","COPY",0),
	  (8,"digglike.action.copy.name","digglike.action.copy.description","jsp/admin/plugins/digglike/DoCopyDigg.jsp","images/admin/skin/plugins/digglike/actions/editcopy.png","COPY",1),
	  (9,"digglike.action.delete.name","digglike.action.delete.description","jsp/admin/plugins/digglike/ConfirmRemoveDigg.jsp","images/admin/skin/plugins/digglike/actions/delete.png","DELETE",0);
	  
--
-- Init  table `digglike_vote_type`
--
     insert into digglike_vote_type (id_vote_type,title)
     values
     		(1,"Vote");
--
-- Init  table `digglike_category`
--
     insert into digglike_category (id_category,title)
     values
     		(1,"Categorie 1"),
     		(2,"Categorie 2");
 --
-- Init  table `digglike_digg_submit_state`
--
     insert into digglike_digg_submit_state (id_state,title,number)
     values
     		(1,"D�sactiv�",1),
     		(3,"Publi�",3);
--
-- Init  table `digglike_default_message`
--

         
insert into digglike_default_message (unavailability_message,libelle_validate_button,libelle_contribution,number_digg_submit_in_top_score,number_digg_submit_in_top_comment,number_digg_submit_caracters_shown)values("","","",10,10,500);


--
-- Init  table `digglike_default_message`
--

insert into `digglike_export_format` (`id_export`,`title`,`description`,`extension`,`xsl_file`) values
 (1,'xml','Exporter les propositions au format xml','xml',0x3C3F786D6C2076657273696F6E3D22312E302220656E636F64696E673D2249534F2D383835392D31223F3E0D0A3C78736C3A7374796C6573686565742076657273696F6E3D22312E302220786D6C6E733A78736C3D22687474703A2F2F7777772E77332E6F72672F313939392F58534C2F5472616E73666F726D223E0D0A3C78736C3A6F7574707574206D6574686F643D22786D6C222076657273696F6E3D22312E302220656E636F64696E673D2249534F2D383835392D312220696E64656E743D22796573222063646174612D73656374696F6E2D656C656D656E74733D22646967672D7375626D69742D76616C756520646967672D7375626D69742D63617465676F7279222F3E0D0A3C78736C3A74656D706C617465206D617463683D222F223E0D0A203C78736C3A6170706C792D74656D706C617465732073656C6563743D2264696767222F3E200D0A3C2F78736C3A74656D706C6174653E0D0A0D0A3C78736C3A74656D706C617465206D617463683D2264696767223E0D0A090D0A093C646967673E0D0A09093C646967672D7469746C653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7469746C65222F3E0D0A09093C2F646967672D7469746C653E0D0A09093C7375626D6974733E0D0A0909093C78736C3A6170706C792D74656D706C617465732073656C6563743D2264696767732D7375626D69742F646967672D7375626D6974222F3E200D0A09093C2F7375626D6974733E0D0A093C2F646967673E090D0A3C2F78736C3A74656D706C6174653E0D0A0D0A3C78736C3A74656D706C617465206D617463683D22646967672D7375626D6974223E0D0A093C646967672D7375626D69743E0D0A09093C646967672D7375626D69742D646174652D726573706F6E73653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D646174652D726573706F6E7365222F3E0D0A09093C2F646967672D7375626D69742D646174652D726573706F6E73653E0D0A09090D0A09093C646967672D7375626D69742D73636F72653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D73636F7265222F3E0D0A093C2F646967672D7375626D69742D73636F72653E0D0A09090D0A09093C646967672D7375626D69742D6E756D6265722D766F74653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D6E756D6265722D766F7465222F3E0D0A093C2F646967672D7375626D69742D6E756D6265722D766F74653E0D0A09090D0A09093C646967672D7375626D69742D6E756D6265722D636F6D6D656E743E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D6E756D6265722D636F6D6D656E74222F3E0D0A09093C2F646967672D7375626D69742D6E756D6265722D636F6D6D656E743E0D0A09090D0A093C646967672D7375626D69742D76616C75653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D76616C7565222F3E0D0A09093C2F646967672D7375626D69742D76616C75653E0D0A09093C646967672D7375626D69742D63617465676F72793E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D63617465676F7279222F3E0D0A09093C2F646967672D7375626D69742D63617465676F72793E0D0A093C2F646967672D7375626D69743E0D0A3C2F78736C3A74656D706C6174653E0D0A3C2F78736C3A7374796C6573686565743E)
