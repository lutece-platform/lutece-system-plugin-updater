/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE="NO_AUTO_VALUE_ON_ZERO" */;


--
-- Init  table `digglike_entry_type`
--

insert into digglike_entry_type(id_type,title,class_name) values(1,"Url","fr.paris.lutece.plugins.digglike.business.EntryTypeUrl");
insert into digglike_entry_type(id_type,title,class_name) values(2,"Zone de texte court","fr.paris.lutece.plugins.digglike.business.EntryTypeText");
insert into digglike_entry_type(id_type,title,class_name) values(3,"Zone de texte long","fr.paris.lutece.plugins.digglike.business.EntryTypeTextArea");
 
--
-- Init  table `digglike_action`
--
insert into digglike_action( id_action,name_key,description_key,action_url,icon_url,action_permission,digg_state) 
values
	  (1,"digglike.action.modify.name","digglike.action.modify.description","jsp/admin/plugins/digglike/ModifyDigg.jsp","images/admin/skin/plugins/digglike/actions/modify.png","MODIFY",0),
	  (2,"digglike.action.modify.name","digglike.action.modify.description","jsp/admin/plugins/digglike/ModifyDigg.jsp","images/admin/skin/plugins/digglike/actions/modify.png","MODIFY",1),
	  (3,"digglike.action.manageDiggSubmit.name","digglike.action.manageDiggSubmit.description","jsp/admin/plugins/digglike/ManageDiggSubmit.jsp","images/admin/skin/plugins/digglike/actions/proposition.png","MANAGE_DIGG_SUBMIT",0),
	  (4,"digglike.action.manageDiggSubmit.name","digglike.action.manageDiggSubmit.description","jsp/admin/plugins/digglike/ManageDiggSubmit.jsp","images/admin/skin/plugins/digglike/actions/proposition.png","MANAGE_DIGG_SUBMIT",1),
	  (5,"digglike.action.disable.name","digglike.action.disable.description","jsp/admin/plugins/digglike/ConfirmDisableDigg.jsp","images/admin/skin/plugins/digglike/actions/disable.png","CHANGE_STATE",1),
	  (6,"digglike.action.enable.name","digglike.action.enable.description","jsp/admin/plugins/digglike/DoEnableDigg.jsp","images/admin/skin/plugins/digglike/actions/enable.png","CHANGE_STATE",0),
	  (7,"digglike.action.copy.name","digglike.action.copy.description","jsp/admin/plugins/digglike/DoCopyDigg.jsp","images/admin/skin/plugins/digglike/actions/editcopy.png","COPY",0),
	  (8,"digglike.action.copy.name","digglike.action.copy.description","jsp/admin/plugins/digglike/DoCopyDigg.jsp","images/admin/skin/plugins/digglike/actions/editcopy.png","COPY",1),
	  (9,"digglike.action.delete.name","digglike.action.delete.description","jsp/admin/plugins/digglike/ConfirmRemoveDigg.jsp","images/admin/skin/plugins/digglike/actions/delete.png","DELETE",0);
	  
--
-- Init  table `digglike_vote_type`
--
     insert into digglike_vote_type (id_vote_type,title)
     values
     		(1,"Vote");
--
-- Init  table `digglike_category`
--
     insert into digglike_category (id_category,title)
     values
     		(1,"Categorie 1"),
     		(2,"Categorie 2");
 --
-- Init  table `digglike_digg_submit_state`
--
     insert into digglike_digg_submit_state (id_state,title,number)
     values
     		(1,"Désactivé",1),
     		(3,"Publié",3);
--
-- Init  table `digglike_default_message`
--

         
insert into digglike_default_message (unavailability_message,libelle_validate_button,libelle_contribution,number_digg_submit_in_top_score,number_digg_submit_in_top_comment,number_digg_submit_caracters_shown)values("","","",10,10,500);


--
-- Init  table `digglike_default_message`
--

insert into `digglike_export_format` (`id_export`,`title`,`description`,`extension`,`xsl_file`) values
 (1,'xml','Exporter les propositions au format xml','xml',0x3C3F786D6C2076657273696F6E3D22312E302220656E636F64696E673D2249534F2D383835392D31223F3E0D0A3C78736C3A7374796C6573686565742076657273696F6E3D22312E302220786D6C6E733A78736C3D22687474703A2F2F7777772E77332E6F72672F313939392F58534C2F5472616E73666F726D223E0D0A3C78736C3A6F7574707574206D6574686F643D22786D6C222076657273696F6E3D22312E302220656E636F64696E673D2249534F2D383835392D312220696E64656E743D22796573222063646174612D73656374696F6E2D656C656D656E74733D22646967672D7375626D69742D76616C756520646967672D7375626D69742D63617465676F7279222F3E0D0A3C78736C3A74656D706C617465206D617463683D222F223E0D0A203C78736C3A6170706C792D74656D706C617465732073656C6563743D2264696767222F3E200D0A3C2F78736C3A74656D706C6174653E0D0A0D0A3C78736C3A74656D706C617465206D617463683D2264696767223E0D0A090D0A093C646967673E0D0A09093C646967672D7469746C653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7469746C65222F3E0D0A09093C2F646967672D7469746C653E0D0A09093C7375626D6974733E0D0A0909093C78736C3A6170706C792D74656D706C617465732073656C6563743D2264696767732D7375626D69742F646967672D7375626D6974222F3E200D0A09093C2F7375626D6974733E0D0A093C2F646967673E090D0A3C2F78736C3A74656D706C6174653E0D0A0D0A3C78736C3A74656D706C617465206D617463683D22646967672D7375626D6974223E0D0A093C646967672D7375626D69743E0D0A09093C646967672D7375626D69742D646174652D726573706F6E73653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D646174652D726573706F6E7365222F3E0D0A09093C2F646967672D7375626D69742D646174652D726573706F6E73653E0D0A09090D0A09093C646967672D7375626D69742D73636F72653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D73636F7265222F3E0D0A093C2F646967672D7375626D69742D73636F72653E0D0A09090D0A09093C646967672D7375626D69742D6E756D6265722D766F74653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D6E756D6265722D766F7465222F3E0D0A093C2F646967672D7375626D69742D6E756D6265722D766F74653E0D0A09090D0A09093C646967672D7375626D69742D6E756D6265722D636F6D6D656E743E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D6E756D6265722D636F6D6D656E74222F3E0D0A09093C2F646967672D7375626D69742D6E756D6265722D636F6D6D656E743E0D0A09090D0A093C646967672D7375626D69742D76616C75653E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D76616C7565222F3E0D0A09093C2F646967672D7375626D69742D76616C75653E0D0A09093C646967672D7375626D69742D63617465676F72793E0D0A0909093C78736C3A76616C75652D6F662073656C6563743D22646967672D7375626D69742D63617465676F7279222F3E0D0A09093C2F646967672D7375626D69742D63617465676F72793E0D0A093C2F646967672D7375626D69743E0D0A3C2F78736C3A74656D706C6174653E0D0A3C2F78736C3A7374796C6573686565743E);


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
 
