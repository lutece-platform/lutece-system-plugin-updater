/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE="NO_AUTO_VALUE_ON_ZERO" */;




--
-- Table structure for table `digglike_default_message`
--
DROP TABLE IF EXISTS `digglike_default_message`;
CREATE TABLE `digglike_default_message` (
  `unavailability_message` text,
  `libelle_validate_button`varchar(255),
  `libelle_contribution` varchar(255),
  `number_digg_submit_in_top_score`int(11),
  `number_digg_submit_in_top_comment`int(11),
  `number_digg_submit_caracters_shown`int(11)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_digg`
--

DROP TABLE IF EXISTS `digglike_digg`;
CREATE TABLE `digglike_digg` (
  `id_digg` int(11) NOT NULL default 0,
  `title` text ,
  `unavailability_message` text,
  `workgroup` varchar(255),
  `id_vote_type` int(11) NOT NULL default 0,
  `number_vote_required` int(11),
  `number_day_required` int(11),
  `active_digg_submit_authentification` tinyint(1) default 0,
  `active_vote_authentification` tinyint(1) default 0,
  `active_comment_authentification` tinyint(1) default 0,
  `disable_new_digg_submit` tinyint(1) default 0,
  `authorized_comment` tinyint(1) default 0,
  `disable_new_comment` tinyint(1) default 0,
  `id_mailing_list_digg_submit` int(11) default NULL,
  `id_mailing_list_comment` int(11) default NULL,
  `active_captcha` tinyint(1) default 0,
  `active` tinyint(1) default 0,
  `date_creation` timestamp NULL default NULL,
  `libelle_validate_button` varchar(255),
  `active_digg_proposition_state` tinyint(1) default 0,
  `libelle_contribution` varchar(255) NOT NULL,
  `number_digg_submit_in_top_score`int(11),
  `number_digg_submit_in_top_comment`int(11),
  `limit_number_vote` tinyint(1) default NULL,
  `number_digg_submit_caracters_shown`int(11),
  `show_category_block` tinyint(1) default 0,
  `show_top_score_block` tinyint(1) default 0,
  `show_top_comment_block` tinyint(1) default 0,
   
  PRIMARY KEY  (`id_digg`),
  KEY `vote_type_fk` (`id_vote_type`),
  CONSTRAINT `fk_vote_type` FOREIGN KEY (`id_vote_type`) REFERENCES `digglike_vote_type` (`id_vote_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_vote_type`
--

DROP TABLE IF EXISTS `digglike_vote_type`;
CREATE TABLE `digglike_vote_type` (
  `id_vote_type` int(11) NOT NULL default '0',
  `title` varchar(255),
  PRIMARY KEY  (`id_vote_type`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_entry`
--

DROP TABLE IF EXISTS `digglike_entry`;
CREATE TABLE `digglike_entry` (
  `id_entry` int(11) NOT NULL default 0,
  `id_digg` int(11) NOT NULL default 0,
  `id_type` int(11) NOT NULL default 0,
  `title` text,
  `help_message` text,
  `entry_comment` text,
  `mandatory` tinyint(1) default 0,
  `position` int(11) default NULL,
  `default_value` text,
  `height` int(11) default NULL,
  `width` int(11) default NULL,
  `max_size_enter` int(11) default NULL,
  `show_in_digg_submit_list` tinyint(1) default 0,
  PRIMARY KEY  (`id_entry`),
  KEY `digg_fk` (`id_digg`),
  KEY `entry_type_fk` (`id_type`),
  CONSTRAINT `fk_entry_type` FOREIGN KEY (`id_type`) REFERENCES `digglike_entry_type` (`id_type`),
  CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_entry_type`
--

DROP TABLE IF EXISTS `digglike_entry_type`;
CREATE TABLE `digglike_entry_type` (
  `id_type` int(11) NOT NULL default 0,
  `title` varchar(255),
  `class_name` varchar(255),
  PRIMARY KEY  (`id_type`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




--
-- Table structure for table `digglike_category`
--

DROP TABLE IF EXISTS `digglike_category`;
CREATE TABLE `digglike_category` (
	`id_category` int(11) NOT NULL,
	`title` varchar(100) NOT NULL,
	PRIMARY KEY  (`id_category`)	
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_digg_category`
--

DROP TABLE IF EXISTS `digglike_digg_category`;
CREATE TABLE `digglike_digg_category` (
  `id_digg` int(11) NOT NULL default 0,
  `id_category` int(11) NOT NULL default 0,
  PRIMARY KEY  (`id_digg`,`id_category`),
  KEY `contain3_fk` (`id_digg`),
  KEY `contain3_fk2` (`id_category`),
  CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`),
  CONSTRAINT `fk_category` FOREIGN KEY (`id_category`) REFERENCES `digglike_category` (`id_category`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;




--
-- Table structure for table `digglike_regular_expression`
--

DROP TABLE IF EXISTS `digglike_regular_expression`;
CREATE TABLE `digglike_regular_expression` (
  `id_expression` int(11) NOT NULL default 0,
  `title` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `valid_exemple` varchar(255) NOT NULL,
  `information_message` text NOT NULL,
  `error_message` text,
  PRIMARY KEY  (`id_expression`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_response`
--

DROP TABLE IF EXISTS `digglike_response`;
CREATE TABLE `digglike_response` (
  `id_response` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `response_value`  text,
  `id_entry` int(11) default NULL,
   PRIMARY KEY  (`id_response`),
   KEY `entry_fk` (`id_entry`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_digg_submit`
--

DROP TABLE IF EXISTS `digglike_digg_submit`;
CREATE TABLE `digglike_digg_submit` (
   `id_digg_submit` int(11) NOT NULL default 0,
   `id_digg` int(11) NOT NULL default 0,
   `id_state` int(11) NOT NULL default 0,
   `user_login` varchar(100) collate utf8_unicode_ci default NULL,
   `date_response` timestamp NULL default NULL,
   `vote_number`  int(11) default NULL,
   `score_number` int(11) default NULL,
   `id_category` int(11) default NULL ,
   `digg_submit_value`  text,
   `digg_submit_title`  text,
   `comment_enable_number`  int(11) default NULL,
   `digg_submit_value_show_in_the_list`  text,
   `reported` tinyint(1) default 0,
   `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL,
   PRIMARY KEY  (`id_digg_submit`),
   KEY `digg_fk` (`id_digg`),
   KEY `category_fk` (`id_category`),
   CONSTRAINT `fk_category` FOREIGN KEY (`id_category`) REFERENCES `digglike_category` (`id_category`),
   CONSTRAINT `fk_digg` FOREIGN KEY (`id_digg`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
--
--
-- Table structure for table `digglike_digg_submit_state`
--

DROP TABLE IF EXISTS `digglike_digg_submit_state`;
CREATE TABLE `digglike_digg_submit_state` (
  `id_state` int(3) NOT NULL default 0,
  `title` varchar(255),
  `number` int(3) NOT NULL default 0,
	 PRIMARY KEY  (`id_state`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote`
--

DROP TABLE IF EXISTS `digglike_comment_submit`;
CREATE TABLE `digglike_comment_submit` (
  `id_comment_submit` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `date_comment` timestamp NULL default NULL,
  `comment_value`  text,
  `active` tinyint(1) default 0,
  `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL,
  
   PRIMARY KEY  (`id_comment_submit`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Table structure for table `digglike_response`
--

DROP TABLE IF EXISTS `digglike_response`;
CREATE TABLE `digglike_response` (
  `id_response` int(11) NOT NULL default 0,
  `id_digg_submit` int(11) default NULL,
  `response_value`  text,
  `id_entry` int(11) default NULL,
   PRIMARY KEY  (`id_response`),
   KEY `entry_fk` (`id_entry`),
   KEY `digg_submit_fk` (`id_digg_submit`),
   
   CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
   CONSTRAINT `fk_digg_submit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg` (`id_digg`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_verify_by`
--

DROP TABLE IF EXISTS `digglike_entry_verify_by`;
CREATE TABLE `digglike_entry_verify_by` (
  `id_entry` int(11) NOT NULL default 0,
  `id_expression` int(11) NOT NULL default 0,
  PRIMARY KEY  (`id_entry`,`id_expression`),
  KEY `contain3_fk` (`id_entry`),
  KEY `contain3_fk2` (`id_expression`),
  CONSTRAINT `fk_entry` FOREIGN KEY (`id_entry`) REFERENCES `digglike_entry` (`id_entry`),
  CONSTRAINT `fk_expression_reguliere` FOREIGN KEY (`id_expression`) REFERENCES `digglike_regular_expression` (`id_expression`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



--
-- Table structure for table `digglike_action`
--

DROP TABLE IF EXISTS `digglike_action`;
CREATE TABLE `digglike_action` (
  `id_action` int(11) NOT NULL default 0,
  `name_key` varchar(100) collate utf8_unicode_ci default NULL,
  `description_key` varchar(100) collate utf8_unicode_ci default NULL,
  `action_url` varchar(255) collate utf8_unicode_ci default NULL,
  `icon_url` varchar(255) collate utf8_unicode_ci default NULL,
  `action_permission` varchar(255) collate utf8_unicode_ci default NULL,
  `digg_state` tinyint(1) default 0,
  PRIMARY KEY  (`id_action`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_tag_submit`
--

DROP TABLE IF EXISTS `digglike_tag_submit`;
CREATE TABLE `digglike_tag_submit` (
   `id_tag_submit` int(11) NOT NULL default 0,
   `id_digg_submit` int(11) NOT NULL default 0,
   `tag_value`  text,
    PRIMARY KEY  (`id_tag_submit`),
    KEY `diggsubmit_fk` (`id_digg_submit`),
	CONSTRAINT `fk_diggsubmit` FOREIGN KEY (`id_digg_submit`) REFERENCES `digglike_digg_submit` (`id_digg_submit`)

)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote_type_vote_button`
--

DROP TABLE IF EXISTS `digglike_vote_type_vote_button`;
CREATE TABLE `digglike_vote_type_vote_button` (
  `id_vote_type` int(11) NOT NULL default 0,
  `id_vote_button` int(11) NOT NULL default 0,
  `vote_button_order` int(11) default NULL ,
  
  PRIMARY KEY  (`id_vote_type`,`id_vote_button`),
  KEY `contain3_fk` (`id_vote_type`),
  KEY `contain3_fk2` (`id_vote_button`),
  CONSTRAINT `fk_votetype` FOREIGN KEY (`id_vote_type`) REFERENCES `digglike_vote_type` (`id_vote_type`),
  CONSTRAINT `fk_votebutton` FOREIGN KEY (`id_vote_button`) REFERENCES `digglike_vote_button` (`id_vote_button`)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote_button`
--

DROP TABLE IF EXISTS `digglike_vote_button`;
CREATE TABLE `digglike_vote_button` (
	`id_vote_button` int(11) NOT NULL,
	`title` varchar(100) NOT NULL,
	`vote_button_value` int(11) default NULL,
	`icon_content` longblob DEFAULT NULL,
	`icon_mime_type` varchar(100) DEFAULT NULL,
	PRIMARY KEY  (`id_vote_button`)

) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_vote`
--

DROP TABLE IF EXISTS `digglike_vote`;
CREATE TABLE `digglike_vote` (
    `id_digg_submit` int(11) NOT NULL default 0,
      `lutece_user_key` varchar(100) collate utf8_unicode_ci default NULL
 )  ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


--
-- Table structure for table `digglike_export_format`
--

DROP TABLE IF EXISTS `digglike_export_format`;
CREATE TABLE `digglike_export_format` (
  `id_export` int(11) NOT NULL default '0',
  `title` varchar(255) default NULL,
  `description` varchar(255) default NULL,
  `extension` varchar(255) default NULL,
  `xsl_file` blob,
  PRIMARY KEY  (`id_export`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
 
