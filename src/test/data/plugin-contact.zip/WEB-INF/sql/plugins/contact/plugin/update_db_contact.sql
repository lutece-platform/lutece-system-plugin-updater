--Structure of db contact
ALTER TABLE `contact` DROP `contact_order`;