--
-- Structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE `contact` (
  `id_contact` int(11) NOT NULL default '0',
  `description` varchar(50) NOT NULL default '',
  `email` varchar(100) NOT NULL default '',
  `contact_order` int(11) NOT NULL default '0',
  `workgroup_key` varchar(50) NOT NULL default 'all',  
  PRIMARY KEY  (`id_contact`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Structure for table `list`
--

DROP TABLE IF EXISTS `contact_list`;
CREATE TABLE `contact_list` (
  `id_contact_list` int(11) NOT NULL default '0',
  `label_contact_list` varchar(50) NOT NULL default '',
  `description_contact_list` varchar(255) NOT NULL default '',
  `workgroup_key` varchar(50) NOT NULL default 'all',  
  PRIMARY KEY  (`id_contact_list`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


--
-- Couples of lists and contacts. Permits to join a list and a contact
--

DROP TABLE IF EXISTS `contact_list_contact`;
CREATE TABLE `contact_list_contact` (
  `id_contact_list` int(11) NOT NULL default '0',
  `id_contact` int(11) NOT NULL default '0',
  `contact_order` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id_contact_list`,`id_contact`, `contact_order`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
